Username: CleanX Portal
Password: wpI8tCyihqRWP2UW