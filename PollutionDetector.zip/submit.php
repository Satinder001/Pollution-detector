
<!DOCTYPE html>
<html>
<head>
	  <link rel="stylesheet" href="css/styles.css">
	 
</head>
<title>Pollution Detector Gallery</title>


<body>


<h2>THANKS FOR UPLOADING</h2>

<h4>You can upload a new image from <a href="index.php">here</a></h4>


</body>
</html>